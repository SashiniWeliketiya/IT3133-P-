function Name(){
    const name = "IT3133 P";
    return(
        <h1>{name}</h1>
    );
};

export default Name;